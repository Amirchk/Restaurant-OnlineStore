<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET["id"];

    // Retrieve item details
    $query = "SELECT * FROM items WHERE id = $id";
    $result = $mysqli->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    }
}
?>

<html>
<head>
    <title>Update Item</title>
</head>
<body>
    <h1>Update Item</h1>
    <form action="update_item.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo $row['name']; ?>" required><br>
        <label for="description">Description:</label>
        <input type="text" name="description" value="<?php echo $row['description']; ?>" required><br>
        <label for="quantity">Quantity:</label>
        <input type="number" name="quantity" value="<?php echo $row['quantity']; ?>" required><br>
        <label for="price">Price:</label>
        <input type="number" name="price" value="<?php echo $row['price']; ?>" required><br>
        <input type="submit" value="Update Item">
    </form>
</body>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $description = $_POST["description"];
    $quantity = $_POST["quantity"];
    $price = $_POST["price"];

    $query = "UPDATE items SET name = '$name', description = '$description', quantity = $quantity, price = $price WHERE id = $id";

    if ($mysqli->query($query) === TRUE) {
        header("Location: Admin.php#inventory");
    } else {
        echo "Error: " . $query . "<br>" . $mysqli->error;
    }
}

$mysqli->close();
?>
