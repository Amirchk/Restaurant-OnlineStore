<?php
include("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    if(isset($_SESSION["username"])){
        $username = $_SESSION["username"];
        $dishName = $_POST["dish_name"];
        $price = $_POST["price"];
        // Insert the order into the database
        $sql = "INSERT INTO orders (username,order_name, price) VALUES (?,?, ?)";
        if ($stmt = $mysqli->prepare($sql)) {
            $stmt->bind_param("ssd", $username,$dishName, $price);
            $stmt->execute();
            $stmt->close();
        }
    
        $mysqli->close();
        echo "Order placed successfully!";
    }else{
        echo "Error Occur while ordering";
    }
}
?>
