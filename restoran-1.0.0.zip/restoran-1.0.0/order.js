
const orderButtons = document.querySelectorAll('.order-button');
const orderList = document.getElementById('order-list');

orderButtons.forEach(button => {
    button.addEventListener("click", () => {
        const dishName = button.parentElement.querySelector(".dish-name").textContent;
        const price = button.parentElement.querySelector(".dish-price").textContent;


        const xhr = new XMLHttpRequest();
        xhr.open("GET", "check_session.php", true);

        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                const response = xhr.responseText;
                console.log("Clikced");
                if (response === "userIsSet") {
                    if (window.confirm("Do you want to confirm Order?\n" + "Dish = " + dishName + "\nPrice = Rs:" + price + "\-")) {
                        // User clicked "OK" (Yes) in the confirmation popup
                        // Send an AJAX request to the server to store the order
                        const xhr = new XMLHttpRequest();
                        xhr.open("POST", "process_order.php", true);
                        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        xhr.onload = function () {
                            if (xhr.status === 200) {
                                // Order placed successfully, add it to the order list
                                const listItem = document.createElement("li");
                                const priceofItem = document.createElement("span");
                                listItem.style.listStyleType = "none";
                                listItem.innerText = `${dishName}`;
                                priceofItem.innerText =  price;
                                listItem.appendChild(priceofItem);
                                orderList.appendChild(listItem);
                            }
                        };
            
                        xhr.send(`dish_name=${dishName}&price=${price}`);
                        alert("OrderPlaced Successfully");
                    }
                } else if (response === "userIsNotSet") {
                    alert(" User is not logged in.");
                    // window.location.pathname.replace("order.php", "login.php");
                    var theURL = window.location.pathname;
                    theURL = theURL.replace("/order.php", "/login.php");
                    window.location.pathname=theURL;
                }
            }
        };
        xhr.send();

        

    });
});

// function generateBill() {
//     const orderList = document.getElementById("order-list").getElementsByTagName("li");
//     let totalAmount = 0;

//     for (let i = 0; i < orderList.length; i++) {
//         const dishName = orderList[i].textContent.trim();
//         const dishPrice = orderList[i].querySelector("span").textContent;
//         totalAmount += parseInt(dishPrice);
//     }

//     // Add total amount to PDF
//     pdf.text(10, 10 + orderList.length * 10 + 10, `Total Amount: $${totalAmount}`);

//     // Save the PDF with a filename
//     alert("PDF SAVED");
// }

function generateBill() {
    const orderList = document.getElementById("order-list").getElementsByTagName("li");
    let totalAmount = 0;

    // Define the document definition
    const documentDefinition = {
        content: [
            { text: "Bill", style: "header" },
            { text: "\n" },
        ],
        styles: {
            header: {
                fontSize: 18,
                bold: true,
            },
        },
    };

    for (let i = 0; i < orderList.length; i++) {
        const dishName = orderList[i].textContent.trim();
        const dishPrice = orderList[i].querySelector("span").textContent;
        totalAmount += parseInt(dishPrice);

        // Add item to the document definition
        documentDefinition.content.push(
            `${dishName}: $${dishPrice}`
        );
    }

    // Add total amount to the document definition
    documentDefinition.content.push(
        { text: `Total Amount: $${totalAmount}`, style: "total" }
    );

    documentDefinition.styles.total = {
        fontSize: 16,
        bold: true,
        alignment: "right",
    };

    // Generate the PDF
    pdfMake.createPdf(documentDefinition).download("bill.pdf");
}
