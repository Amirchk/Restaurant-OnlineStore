
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Panel Login</title>
    <!-- Add your CSS styles here -->
</head>

<body>
    <div class="container">
        <h1>Admin Panel Login</h1>
        <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required><br><br>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required><br><br>
            <button type="submit">Login</button>
        </form>
    </div>
    <?php
    session_start();
    $adminName='admin';
    $adminPss='admin123';
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if($_POST["username"]==$adminName && $_POST["password"]==$adminPss){
            $_SESSION['admin_logged_in']=true;
            header("Location: Admin.php");
        }
        
    }
    
// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     // Check admin credentials (replace with your own admin username and password)
//     $admin_username = 'admin';
//     $admin_password = 'admin123';

//     $input_username = $_POST['username'];
//     $input_password = $_POST['password'];

//     if ($input_username == $admin_username && $input_password == $admin_password) {
//         // Admin login successful
//         echo '<h1>awdawdad</h1>';
//         $_SESSION['admin_logged_in'] = true;
//         echo '<script type="text/javascript">window.location = "Admin.php";</script>';
//     } else {
//         // Admin login failed
//         header('Location: Admin_login.php');
//         exit();
//     }
// }


?>
</body>
</html>