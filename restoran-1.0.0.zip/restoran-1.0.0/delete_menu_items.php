<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET["id"];

    $query = "DELETE FROM menu_items WHERE id = $id";

    if ($mysqli->query($query) === TRUE) {
        header("Location: menuItems.php");
    } else {
        echo "Error: " . $query . "<br>" . $mysqli->error;
    }
}

$mysqli->close();
?>
