function generateExcel() {
     // Create a new Excel workbook
     const workbook = new ExcelJS.Workbook();
     const worksheet = workbook.addWorksheet('Report');
 
     // Retrieve the table data
     const tableRows = document.querySelectorAll('#tableId-1');
 
     // Iterate through the table rows and add data to the worksheet
     tableRows.forEach(row => {
        var rowData = [];
         const cells = row.querySelectorAll('td');
         cells.forEach(cell => {
             rowData.push(cell.textContent);
         });
         worksheet.addRow(rowData);
         rowData=[]
     });
 
     // Create a Blob to save the workbook as a file
     workbook.xlsx.writeBuffer().then(buffer => {
         const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
         saveAs(blob, 'report.xlsx');
     });
}
