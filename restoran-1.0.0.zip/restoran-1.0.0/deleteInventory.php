<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET["id"];

    $query = "DELETE FROM items WHERE id = $id";

    if ($mysqli->query($query) === TRUE) {
        header("Location: inventory.php");
    } else {
        echo "Error: " . $query . "<br>" . $mysqli->error;
    }
}

$mysqli->close();
?>
