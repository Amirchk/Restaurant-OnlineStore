<?php include "config.php"; ?>


<?php
// Assuming you have a MySQLi connection established

// Query to retrieve the total number of customers, orders, and menu items
$totalCustomers = 0;
$totalOrders = 0;
$totalMenuItems = 0;

// Replace with your actual database queries to get these totals
// For example, you can use SELECT COUNT(*) FROM your_table to count records

// Example query for total customers:
$queryCustomers = "SELECT COUNT(distinct username) AS total_customers FROM orders";
$resultCustomers = mysqli_query($mysqli, $queryCustomers);
if ($resultCustomers) {
    $row = mysqli_fetch_assoc($resultCustomers);
    $totalCustomers = $row['total_customers'];
}

// Example query for total orders:
$queryOrders = "SELECT COUNT(cart_id) AS total_orders FROM orders";
$resultOrders = mysqli_query($mysqli, $queryOrders);
if ($resultOrders) {
    $row = mysqli_fetch_assoc($resultOrders);
    $totalOrders = $row['total_orders'];
}

// Example query for total menu items:
$queryMenuItems = "SELECT COUNT(dishname) AS total_menu_items FROM menu_items";
$resultMenuItems = mysqli_query($mysqli, $queryMenuItems);
if ($resultMenuItems) {
    $row = mysqli_fetch_assoc($resultMenuItems);
    $totalMenuItems = $row['total_menu_items'];
}
?>

<html lang="en">



<head>
    <meta charset="utf-8">
    <title>Online Restaurant Management System</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

</head>
<body>
<div class="container-fluid position-relative">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar">
                <div class="position-sticky">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">
                                <i class="fa fa-home me-3"></i>Home
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">
                                <i class="fa fa-info-circle me-3"></i>About
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="service.php">
                                <i class="fa fa-cogs me-3"></i>Service
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="menu.php">
                                <i class="fa fa-utensils me-3"></i>Menu
                            </a>
                        </li>
                        <?php
                        session_start();
                        if (isset($_SESSION["username"])) {
                            echo '<li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-in-left me-2"></i>Log Out</a></li>';
                        } else {
                            echo '<li class="nav-item"><a class="nav-link" href="login.php"><i class="bi bi-box-arrow-right"></i> Log In</a></li>';
                        }
                        ?>
                        <li class="nav-item">
                            <a class="nav-link" href="order.php">
                                <i class="fa fa-shopping-cart me-3"></i>Order
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="Gallary.php">
                                <i class="fa fa-image me-3"></i>Gallary
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php">
                                <i class="fa fa-envelope me-3"></i>Contact
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="cart.php">
                                <i class="fa fa-shopping-cart me-3"></i>Cart
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="booking.php">
                                <i class="fa fa-book me-3"></i>Booking
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="team.php">
                                <i class="fa fa-users me-3"></i>Our Team
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="testimonial.php">
                                <i class="fa fa-comments me-3"></i>Testimonial
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="inventory.php">
                                <i class="fa fa-archive me-3"></i>Inventory
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="menuItems.php">
                            <i class="bi bi-bag-plus-fill me-2"></i>Menu Management
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Content goes here -->
                <div class="container">
        <!-- Top Row -->
        <div class="row mt-4">
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-people-fill"></i> Total Customers</h5>
                        <p class="card-text"><?php echo $totalCustomers; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-bag-check"></i> Total Orders</h5>
                        <p class="card-text"><?php echo $totalOrders; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-menu-up"></i> Total Menu Items</h5>
                        <p class="card-text"><?php echo $totalMenuItems; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Order Management Table -->
        <div class="row mt-4">
            <div class="col">
                <h2>Order Management</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer Name</th>
                            <th>Order</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Add your PHP code for populating the Order Management table here
                            $query = "SELECT * FROM orders";
                            $result = mysqli_query($mysqli, $query);

                            while ($row = mysqli_fetch_assoc($result)) {
                                echo '<tr>';
                                echo '<td>' . $row['cart_id'] . '</td>';
                                echo '<td>' . $row['username'] . '</td>';
                                echo '<td>' . $row['order_name'] . '</td>';
                                echo '<td>' . $row['price'] . '</td>';
                                echo '</tr>';
                            }
                        ?>
                    </tbody>
                </table>
                <button onclick="generateExcel()">Generate Excel File</button>
            </div>
        </div>

        <!-- Inventory Table -->
        <div class="row mt-4">
            <div class="col">
                <h2>Inventory Management</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Add your PHP code for populating the Inventory table here
                            $query = "SELECT * FROM items";
                            $result = $mysqli->query($query);

                            while ($row = $result->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . $row['id'] . '</td>';
                                echo '<td>' . $row['name'] . '</td>';
                                echo '<td>' . $row['description'] . '</td>';
                                echo '<td>' . $row['quantity'] . '</td>';
                                echo '<td>' . $row['price'] . '</td>';
                                echo '<td><a href="update_item.php?id=' . $row['id'] . '"><i class="bi bi-pencil-square"></i></a> | <a href="deleteInventory.php?id=' . $row['id'] . '"><i class="bi bi-trash"></i></a></td>';
                                echo '</tr>';
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Reservations Table -->
        <div class="row mt-4">
            <div class="col">
                <h2>Reservations</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Date/Time</th>
                            <th>People</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Add your PHP code for populating the Reservations table here
                            $query = "SELECT * FROM reservations";
                            $result = $mysqli->query($query);

                            while ($row = $result->fetch_assoc()) {
                                echo '<tr>';
                                echo '<td>' . $row['id'] . '</td>';
                                echo '<td>' . $row['username'] . '</td>';
                                echo '<td>' . $row['phone'] . '</td>';
                                echo '<td>' . $row['datetime'] . '</td>';
                                echo '<td>' . $row['people'] . '</td>';
                                echo '<td>' . $row['message'] . '</td>';
                                echo '</tr>';
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
            </main>
        </div>
    </div>


    
</body>
</html>
