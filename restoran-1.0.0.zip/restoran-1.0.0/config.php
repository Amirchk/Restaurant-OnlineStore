<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "restaurant_db";

$mysqli = new mysqli($host, $user, $password, $database);

if ($mysqli === false) {
    die("Error: Could not connect to the database.");
}
?>
