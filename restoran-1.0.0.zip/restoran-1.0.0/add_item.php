<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $description = $_POST["description"];
    $quantity = $_POST["quantity"];
    $price = $_POST["price"];

    $query = "INSERT INTO items (name, description, quantity, price) VALUES ('$name', '$description', $quantity, $price)";
    
    if ($mysqli->query($query) === TRUE) {
        header("Location: inventory.php");
    } else {
        echo "Error: " . $query . "<br>" . $mysqli->error;
    }
}

$mysqli->close();
?>
