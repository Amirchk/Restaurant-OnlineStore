<?php include('config.php'); ?>


<?php
// Assuming you have a MySQLi connection established

// Query to retrieve the total number of customers, orders, and menu items
$totalCustomers = 0;
$totalOrders = 0;
$totalMenuItems = 0;

// Replace with your actual database queries to get these totals
// For example, you can use SELECT COUNT(*) FROM your_table to count records

// Example query for total customers:
$queryCustomers = "SELECT COUNT(distinct username) AS total_customers FROM orders";
$resultCustomers = mysqli_query($mysqli, $queryCustomers);
if ($resultCustomers) {
    $row = mysqli_fetch_assoc($resultCustomers);
    $totalCustomers = $row['total_customers'];
}

// Example query for total orders:
$queryOrders = "SELECT COUNT(cart_id) AS total_orders FROM orders";
$resultOrders = mysqli_query($mysqli, $queryOrders);
if ($resultOrders) {
    $row = mysqli_fetch_assoc($resultOrders);
    $totalOrders = $row['total_orders'];
}

// Example query for total menu items:
$queryMenuItems = "SELECT COUNT(dishname) AS total_menu_items FROM menu_items";
$resultMenuItems = mysqli_query($mysqli, $queryMenuItems);
if ($resultMenuItems) {
    $row = mysqli_fetch_assoc($resultMenuItems);
    $totalMenuItems = $row['total_menu_items'];
}
?>


<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Online Restaurant Management System</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/exceljs/4.3.0/exceljs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

</head>


<body>
    <section>
        <?php include "Navbar.php"; ?>
    </section>
    <?php 
    if(!isset($_SESSION["admin_logged_in"])){
        echo '<script type="text/javascript">window.location = "Admin_login.php";</script>';
    }
     ?>
    <div class="container-fluid position-relative">
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-dark sidebar">
                <div class="position-sticky">
                    <ul class="nav flex-column position-sticky">
                        
                        
                        
                        <li class="nav-item">
                            <a class="nav-link" href="Admin_logout.php">
                                <i class="bi bi-box-arrow-in-left me-2"></i>Logout Admin
                            </a>
                        </li>
                        <?php
                        // session_start();
                        // if (isset($_SESSION["username"])) {
                        //     echo '<li class="nav-item"><a class="nav-link" href="logout.php"><i class="bi bi-box-arrow-in-left me-2"></i>Log Out</a></li>';
                        // } else {
                        //     echo '<li class="nav-item"><a class="nav-link" href="login.php"><i class="bi bi-box-arrow-right"></i> Log In</a></li>';
                        // }
                        ?>
                        
                                               
                        
                        <li class="nav-item">
                            <a class="nav-link"  href="#inventory">
                                <i class="fa fa-archive"></i> Inventory Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#MenuItems">
                                <i class="bi bi-bag-plus-fill me-2"></i>Menu Management
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#reserveOrders">
                            <i class="bi bi-calendar-check me-2"></i>Reserved Orders
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <!-- Content goes here -->
                <div class="container">
                    <!-- Top Row -->
                    <div class="row mt-4">
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="bi bi-people-fill"></i> Total Customers</h5>
                                    <p class="card-text">
                                        <?php echo $totalCustomers; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="bi bi-bag-check"></i> Total Orders</h5>
                                    <p class="card-text">
                                        <?php echo $totalOrders; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title"><i class="bi bi-menu-up"></i> Total Menu Items</h5>
                                    <p class="card-text">
                                        <?php echo $totalMenuItems; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Order Management Table -->
                    <div class="row mt-4">
                        <div class="col">
                            <h2>Customer Orders Management</h2>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer Name</th>
                                        <th>Order</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Add your PHP code for populating the Order Management table here
                                    $query = "SELECT * FROM orders";
                                    $result = mysqli_query($mysqli, $query);

                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo '<tr>';
                                        echo '<td>' . $row['cart_id'] . '</td>';
                                        echo '<td>' . $row['username'] . '</td>';
                                        echo '<td>' . $row['order_name'] . '</td>';
                                        echo '<td>' . $row['price'] . '</td>';
                                        echo '</tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <button onclick="generateExcel()">Generate Excel File</button>
                        </div>
                    </div>

                    <!-- Inventory Table -->
                    <div class="row mt-4">
                        <div class="col">
                            <h2 id="inventory">Inventory/Orders Management<a href="inventory.php"><i
                                        class="bi bi-pencil-square"></i></a></h2>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <!-- <th>Action</th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Add your PHP code for populating the Inventory table here
                                    $query = "SELECT * FROM items";
                                    $result = $mysqli->query($query);

                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        echo '<td>' . $row['id'] . '</td>';
                                        echo '<td>' . $row['name'] . '</td>';
                                        echo '<td>' . $row['description'] . '</td>';
                                        echo '<td>' . $row['quantity'] . '</td>';
                                        echo '<td>' . $row['price'] . '</td>';
                                        // echo '<td><a href="update_item.php?id=' . $row['id'] . '"><i class="bi bi-pencil-square"></i></a> | <a href="deleteInventory.php?id=' . $row['id'] . '"><i class="bi bi-trash"></i></a></td>';
                                        echo '</tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- MenuItems Table -->
                    <div class="row mt-4">
                        <div class="col">
                            <h2 id="MenuItems" >Menu Items<a href="menuItems.php"><i
                                        class="bi bi-pencil-square"></i></a></h2>
                            <?php
                            //connect to database
                            include "config.php";

                            $query = "SELECT * FROM menu_items";
                            $result = $mysqli->query($query);

                            if ($result->num_rows > 0) {
                                echo '<table class="table">';
                                echo "<tr><th>ID</th><th>Dish Name</th><th>Description</th><th>Menu Item Type</th><th>Price</th></tr>";

                                while ($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . $row['id'] . "</td>";
                                    echo "<td>" . $row['dishname'] . "</td>";
                                    echo "<td>" . $row['description'] . "</td>";
                                    echo "<td>" . $row['type'] . "</td>";
                                    echo "<td>" . $row['price'] . "</td>";
                                    echo "</tr>";
                                }

                                echo "</table>";
                            } else {
                                echo "No menu items available.";
                            }
                            //close db connection
                            $mysqli->close();
                            ?>
                        </div>
                    </div>

                    <!-- Reservations Table -->
                    <?php include("config.php"); ?>
                    <div class="row mt-4">
                        <div class="col">
                            <h2 id="reserveOrders">Reservations</h2>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Date/Time</th>
                                        <th>People</th>
                                        <th>Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Add your PHP code for populating the Reservations table here
                                    $query = "SELECT * FROM reservations";
                                    $result = $mysqli->query($query);

                                    while ($row = $result->fetch_assoc()) {
                                        echo '<tr>';
                                        echo '<td>' . $row['id'] . '</td>';
                                        echo '<td>' . $row['username'] . '</td>';
                                        echo '<td>' . $row['phone'] . '</td>';
                                        echo '<td>' . $row['datetime'] . '</td>';
                                        echo '<td>' . $row['people'] . '</td>';
                                        echo '<td>' . $row['message'] . '</td>';
                                        echo '</tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Company</h4>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                    <a class="btn btn-link" href="">Reservation</a>
                    <a class="btn btn-link" href="">Privacy Policy</a>
                    <a class="btn btn-link" href="">Terms & Condition</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Contact</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>wah cantt</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+03015409620</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@example.com</p>
                    <div class="d-flex pt-2">
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Opening</h4>
                    <h5 class="text-light fw-normal">Monday - Saturday</h5>
                    <p>09AM - 09PM</p>
                    <h5 class="text-light fw-normal">Sunday</h5>
                    <p>10AM - 08PM</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Newsletter</h4>
                    <p> "Stay updated on all things in DineDelight – subscribe to our flavorful newsletter!"</p>

                    <div class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-primary w-100 py-3 ps-4 pe-5" type="text"
                            placeholder="Your email">
                        <button type="button"
                            class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">SignUp</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">DineDelight</a>, All Right Reserved.
                        <br><br>
                        Designed By SHA
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <script src="js/generateReports.js"></script>


</body>

</html>