<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $id = $_GET["id"];

    // Retrieve menu item details
    $query = "SELECT * FROM menu_items WHERE id = $id";
    $result = $mysqli->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    }
}
?>
<html>
<head>
    <meta charset="utf-8">
    <title>Online Restaurant Management System | Inventory Management</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/orders.css">
</head>
<body>
<div class="container-xxl position-relative p-0">
        <?php include("Navbar.php") ?>
</div>
    <h1>Update Menu Item</h1>
    <form action="update_menu_item.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <label for="dishname">Dish Name:</label>
        <input type="text" name="dishname" value="<?php echo $row['dishname']; ?>" required><br>
        <label for="description">Description:</label>
        <input type="text" name="description" value="<?php echo $row['description']; ?>" required><br>
        <label for="type">Menu Item Type:</label>
        <select name="type">
            <option value="Breakfast" <?php if ($row['type'] == 'Breakfast') echo 'selected'; ?>>Breakfast</option>
            <option value="Lunch" <?php if ($row['type'] == 'Lunch') echo 'selected'; ?>>Lunch</option>
            <option value="Dinner" <?php if ($row['type'] == 'Dinner') echo 'selected'; ?>>Dinner</option>
        </select><br>
        <label for="price">Price:</label>
        <input type="number" name="price" value="<?php echo $row['price']; ?>" required><br>
        <select name="status" >
            <option value="Available" >Available</option>
            <option value="Not Available" >Not Available</option>
        </select>
        <input type="submit" value="Update Menu Item">
    </form>
</body>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $dishname = $_POST["dishname"];
    $description = $_POST["description"];
    $type = $_POST["type"];
    $price = $_POST["price"];
    $status = $_POST["status"];

    $query = "UPDATE menu_items SET dishname = '$dishname', description = '$description', type = '$type', price = $price, status='$status'   WHERE id = $id";

    if ($mysqli->query($query) === TRUE) {
        header("Location: Admin.php");
    } else {
        echo "Error: " . $query . "<br>" . $mysqli->error;
    }
}

$mysqli->close();
?>
