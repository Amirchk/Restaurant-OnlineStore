<?php
session_start();

 if( isset($_SESSION['admin_logged_in']) == true ){
    $_SESSION['admin_logged_in'] = false;
    unset($_SESSION['admin_logged_in']);
    echo '<h1>LoggedOut Go to LandingPage <a href="index.php" >Home</a></h1>';
 }else{
   echo 'If you find any issue then visit <a href="Admin_login.php" >AdminLogin</a> Or visit LandingPage <a href="index.php" >Home</a>';
 }
?>