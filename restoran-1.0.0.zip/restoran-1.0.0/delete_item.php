<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the cart_id sent from the JavaScript
    $cartId = $_POST['cart_id'];

    // Include your database connection code
    include("config.php");

    // Perform the deletion in the database
    $query = "DELETE FROM orders WHERE cart_id = ?";
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'i', $cartId);

    if (mysqli_stmt_execute($stmt)) {
        // Item successfully deleted
        echo 'Item deleted successfully';
    } else {
        // Failed to delete item
        echo 'Error deleting item';
    }

    mysqli_stmt_close($stmt);
    mysqli_close($mysqli);
}
?>
