<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $dishname = $_POST["dishname"];
    $description = $_POST["description"];
    $type = $_POST["type"];
    $price = $_POST["price"];
    $status = $_POST["status"];

    $query = "INSERT INTO menu_items (dishname, description, type, price,status) VALUES ('$dishname', '$description', '$type', $price,'$status')";
    
    if ($mysqli->query($query) === TRUE) {
        header("Location: menuItems.php");
    } else {
        echo "Error: " . $query . "<br>" . $mysqli->error;
    }
}

$mysqli->close();
?>
