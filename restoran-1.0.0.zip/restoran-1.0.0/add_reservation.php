<?php
include("config.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    if(!isset($_SESSION["username"])){
        header("Location: login.php");
    }else{
        $username = $_POST["username"];
        $phone = $_POST["phone"];
        $datetime = $_POST["datetime"];
        $people = $_POST["people"];
        $message = $_POST["message"];
    
        $query = "INSERT INTO reservations (username, phone, datetime, people, message) VALUES ('$username', '$phone', '$datetime', $people, '$message')";
        
        if ($mysqli->query($query) === TRUE) {
            header("Location: booking.php");
        } else {
            echo "Error: " . $query . "<br>" . $mysqli->error;
        }
    }
    
}

$mysqli->close();
?>
